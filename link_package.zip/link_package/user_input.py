LesHouches= []

##################################################################
#
# Python script to link between LesHouches events file+pythia+delphes+madanalysis
####################################################################
run_name = 'Run_1' # Name of the folder to store the outputs
#LesHouches.append('unweighted_events.lhe')
LesHouches.append('sig.lhe')
#LesHouches.append('unweighted_2_events_sig.lhe')
Number_of_lhe_files = 1 # Number of LesHouches files you want to be used
################################################
pythia = 'on'
#Here the user should define pythia options by on/off

Hadronizatoin = 'on'
Decay_of_heavy_hadrons = 'on'
Initial_state_radiation = 'on'
Final_state_radiation = 'on'
Multiple_interaction = 'off'
Beam_remnants = 'on'

# Other options for the merging&matching algorithm has to be chagned by the user (if needed)  
merging = '1'  # If '0' no matching used. '1' CKKW matching '2' MLM matching "recommended"

######################################################
# Fo the moment delphes input card is the default CMS one for RUN-II
Delphes = 'on'  # 'on/off' turn on or off delphes
delphes_card =  'defalut'  #'/Users/ahamedhamad/Downloads/link/delphes/delphes/cards/delphes_card_FCC.tcl'      #'defalut'
################################################
# Write the commands as in madanalysis
# input files for both gen and reco level added automatically
# the cross section for each file will taken automatically from pythia.log files
# You can revise the input cards for madanalysis wihch can found in gen_plot and reco_plt dirs
madanalysis = 'off'
madanalysis_commands='''
define l = l+ l-
define e = e+ e-
define mu = mu+ mu-
set main.stacking_method = superimpose
set main.lumi = 300
set main.normalize = lumi
plot PT( l- l+) 100 0 220 
plot N(j) 100 -5 10 
        '''
